/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herciozita.gestaobibliotecas;

public class Livro {

    private String titulo;
    private String genero;
    private int anoPublicacao;
    private String nomeAutor;
    private int precoEmprestimo;
    private int quantidade;

    public Livro(String titulo, String genero, int anoPublicacao, String nomeAutor, int precoEmprestimo, int quantidade) {
        this.titulo = titulo;
        this.genero = genero;
        this.anoPublicacao = anoPublicacao;
        this.nomeAutor = nomeAutor;
        this.precoEmprestimo = precoEmprestimo;
        this.quantidade = quantidade;
    }
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getNomeAutor() {
        return nomeAutor;
    }

    public void setNomeAutor(String nomeAutor) {
        this.nomeAutor = nomeAutor;
    }

    public int getPrecoEmprestimo() {
        return precoEmprestimo;
    }

    public void setPrecoEmprestimo(int precoEmprestimo) {
        this.precoEmprestimo = precoEmprestimo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

}
