/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herciozita.banco;

import java.util.ArrayList;

public abstract class ContaBancaria {

    private String numeroConta;
    private double saldo;
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    private ArrayList<String> historico;

    public ContaBancaria() {
    }

    public ContaBancaria(String numeroConta, double saldo) {
        this.numeroConta = numeroConta;
        this.saldo = saldo;
        this.historico = new ArrayList<>();
    }

    public abstract void depositar(double valor);

    public abstract void levantar(double valor);

    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public ArrayList<String> getHistorico() {
        return historico;
    }

    public void setHistorico(ArrayList<String> historico) {
        this.historico = historico;
    }

    @Override
    public String toString() {
        return "ContaBancaria{" + "numeroConta=" + numeroConta + ", saldo=" + saldo + '}';
    }

    public void transferir(double quantidade, ContaBancaria destino) {
        this.saldo = destino.saldo - quantidade;
        destino.saldo = destino.saldo + quantidade;

        if (getSaldo() < quantidade) {
            System.out.println("saldo insuficiente para a transferencia");

        } else {
            this.levantar(quantidade);
            destino.depositar(quantidade);
            System.out.println("tranferencia feita com sucesso");
        }
    }
}
