/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herciozita.banco;
public class ContaPoupanca extends ContaBancaria {
private double limite;
    public ContaPoupanca(double limite) {
        this.limite = limite;
    }

    public ContaPoupanca(double limite, String numeroConta, double saldo) {
        super(numeroConta, saldo);
        this.limite = limite;
    }
    @Override
    public void levantar(double valor) {
        if (valor > 0 && valor <= (getSaldo() + limite)) {
            setSaldo(getSaldo() - valor);

            System.out.println("retirou da conta o valor de " + valor );
        } else {
            System.out.println("saldo insuficiente para a operacao");
        }
    }

    @Override
    public void depositar(double valor) {
        this.setSaldo(this.getSaldo() + valor - limite);
        if (valor > 0) {
            System.out.println("deposito realizado com sucesso para a conta" + getNumeroConta());
            System.out.println("voce depositou " + valor);
        } else {
            System.out.println("saldo invalido");
        }

    }
    public void mostrarDados(){
        System.out.println("conta corrente");
        System.out.println("numero da conta:"+getNumeroConta());
        System.out.println("nome do cliente:"+getNome());
        System.out.println("Saldo da conta:"+getSaldo());
        
        
    }
    
    
}
