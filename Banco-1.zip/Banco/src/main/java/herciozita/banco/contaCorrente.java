/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herciozita.banco;

public class contaCorrente extends ContaBancaria {

    private double taxa;

    public contaCorrente(double taxa) {
        this.taxa = taxa;
    }

    public contaCorrente(double taxa, String numeroConta, double saldo) {
        super(numeroConta, saldo);
        this.taxa = taxa;
    }

    @Override
    public void levantar(double valor) {
        if (valor > 0 && valor <= (getSaldo() - taxa)) {
            setSaldo(getSaldo() - valor - taxa);

            System.out.println("retirou da conta o valor de " + valor + "a taxa foi de" + taxa);
        } else {
            System.out.println("saldo insuficiente para a operacao");
        }
    }

    @Override
    public void depositar(double valor) {
        this.setSaldo(this.getSaldo() + valor - taxa);
        if (valor > 0) {
            System.out.println("deposito realizado com sucesso para a conta" + getNumeroConta());
            System.out.println("voce depositou " + valor + "taxa" + taxa);
        } else {
            System.out.println("saldo invalido");
        }

    }
    public void mostrarDados(){
        System.out.println("conta corrente");
        System.out.println("numero da conta:"+getNumeroConta());
        System.out.println("nome do cliente:"+getNome());
        System.out.println("Saldo da conta:"+getSaldo());
        
        
    }

}
