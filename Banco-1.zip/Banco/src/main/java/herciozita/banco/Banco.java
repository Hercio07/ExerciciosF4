/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package herciozita.banco;

/**
 *
 * @author rene
 */
public class Banco {

    public static void main(String[] args) {
       contaBancaria c1= new contaBancaria();
    }
}
